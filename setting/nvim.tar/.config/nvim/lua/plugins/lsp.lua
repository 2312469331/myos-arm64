return {
  {
    "neovim/nvim-lspconfig",
    dependencies = {
      "jose-elias-alvarez/typescript.nvim",
      -- 👇 删掉了重复的 neovim/nvim-lspconfig
    },
    config = function()
      -- 1. LspAttach：绑定 LSP 快捷键
      vim.api.nvim_create_autocmd("LspAttach", {
        callback = function(args)
          local buffer = args.buf
          local client = vim.lsp.get_client_by_id(args.data.client_id)
          if not client then
            return
          end
          -- gd 跳转定义（带 noremap 防止被 which-key 拦截）
          vim.keymap.set("n", "gd", vim.lsp.buf.definition, {
            buffer = buffer,
            desc = "Go to definition",
            noremap = true,
            silent = true,
          })
          -- TypeScript 专用快捷键（仅 tsserver 客户端生效）
          if client.name == "tsserver" then
            vim.keymap.set(
              "n",
              "<leader>co",
              "TypescriptOrganizeImports",
              { buffer = buffer, desc = "Organize Imports" }
            )
            vim.keymap.set("n", "<leader>cR", "TypescriptRenameFile", { desc = "Rename File", buffer = buffer })
          end
        end,
      })
      -- 2. BufEnter：打开 .c/.h 文件时自动启动 clangd（和 LspAttach 平级！）
      vim.api.nvim_create_autocmd("BufEnter", {
        pattern = { "*.c", "*.h" },
        callback = function()
          local clients = vim.lsp.get_active_clients({ name = "clangd" })
          if #clients == 0 then
            vim.cmd("LspStart clangd")
          end
        end,
      })
    end,
    ---@class PluginLspOpts
    opts = {
      -- 🔴 核心：禁止 Mason 自动安装任何 LSP 服务器（解决 Termux 安装失败）
      mason_lspconfig = { auto_install = false },

      ---@type lspconfig.options
      servers = {
        -- Python LSP：暂时关闭自动启动（避免 Mason 尝试安装）
        pyright = { autostart = false },

        -- 🎯 C/C++ LSP：强制使用系统已安装的 clangd，自动启动
        clangd = {
          autostart = true,
          cmd = { "/data/data/com.termux/files/usr/bin/clangd" },
          filetypes = { "c", "cpp", "objc", "objcpp" },
          root_dir = require("lspconfig.util").root_pattern("Makefile", "compile_commands.json", ".git"),
        },

        -- TypeScript LSP：暂时关闭自动启动
        tsserver = { autostart = false },

        -- Makefile LSP：暂时关闭自动启动
        makefile_language_server = { autostart = false },
        asm_lsp = {}, -- 启用 asm-lsp
      },

      setup = {
        -- 跳过 lua_ls 的 Mason 自动安装，消除弹窗
        lua_ls = function()
          return true
        end,

        -- TypeScript 专用配置（需要时再启用）
        tsserver = function(_, opts)
          require("typescript").setup({ server = opts })
          return true
        end,

        -- 让 mason-lspconfig 直接使用我们的 clangd 配置，不做额外处理
        clangd = function(_, opts)
          require("lspconfig").clangd.setup(opts)
          return true
        end,
      },
    },
  },
}
