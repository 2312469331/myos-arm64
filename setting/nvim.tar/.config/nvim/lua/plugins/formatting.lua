return {
  "stevearc/conform.nvim",
  opts = {
    formatters_by_ft = {
      -- 👇 关键：为 C/C++ 指定格式化器
      c = { "clang_format" },
      cpp = { "clang_format" },
      -- ld = { "clang_format" },
      -- 其他语言的配置保持不变
      lua = { "stylua" },
      python = { "isort", "black" },
      -- 绑定 .asm/.S 文件到 asmfmt
      asm = { "asmfmt" },
      tiasm = { "asmfmt" }, -- 兼容 .s 后缀
      -- 其他语言格式化配置...
    },
  },
}
