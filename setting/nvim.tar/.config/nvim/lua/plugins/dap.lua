return {
  -- 核心 DAP 插件
  {
    "mfussenegger/nvim-dap",
    dependencies = {
      -- 👇 新增：必须先装 nvim-nio（nvim-dap-ui 强制依赖）
      "nvim-neotest/nvim-nio",
      -- 调试 UI 面板
      "rcarriga/nvim-dap-ui",
      -- 虚拟文本显示变量值（可选）
      "theHamsta/nvim-dap-virtual-text",
    },
    config = function()
      local dap = require("dap")
      local dapui = require("dapui")
      -- 👇 新增：彻底清理 DAP 窗口的函数
      local function clean_dap_windows()
        -- 1. 先关闭 dap-ui 所有面板
        dapui.close()
        -- 2. 延迟 100ms 后，关闭所有其他分屏（避免和 DAP 事件冲突）
        vim.defer_fn(function()
          vim.cmd("wincmd o") -- 只保留当前窗口
          -- 3. （可选）删除 DAP 相关的残留缓冲区
          for _, buf in ipairs(vim.api.nvim_list_bufs()) do
            local bufname = vim.api.nvim_buf_get_name(buf)
            if bufname:match("dap%-repl") or bufname:match("dap%-ui") then
              pcall(vim.api.nvim_buf_delete, buf, { force = true })
            end
          end
        end, 100)
      end
      -- 初始化 UI（保持你原来的配置）
      dapui.setup()
      require("nvim-dap-virtual-text").setup()
      -- 👇 调试开始时打开 UI
      dap.listeners.after.event_initialized["dapui_config"] = function()
        dapui.open()
      end
      -- 👇 调试结束时自动清理窗口（替换原来的 dapui.close()）
      dap.listeners.before.event_terminated["dapui_clean"] = clean_dap_windows
      dap.listeners.before.event_exited["dapui_clean"] = clean_dap_windows
      -- 👇 重写 DapDisconnect，让它也触发清理
      local original_disconnect = dap.disconnect
      dap.disconnect = function(opts)
        original_disconnect(opts)
        clean_dap_windows()
      end
      -- -- 初始化 UI（保持不变）
      -- dapui.setup()
      -- require("nvim-dap-virtual-text").setup()
      --
      -- -- 自动开关 UI 面板
      -- dap.listeners.after.event_initialized["dapui_config"] = function()
      --   dapui.open()
      -- end
      -- dap.listeners.before.event_terminated["dapui_config"] = function()
      --   dapui.close()
      -- end
      -- dap.listeners.before.event_exited["dapui_config"] = function()
      --   dapui.close()
      -- end
      -- dap.listeners.before.event_disconnected["dapui_config"] = function()
      --   dapui.close()
      -- end
      --
      -- 1. 配置 GDB 适配器（Termux 原生 gdb）
      dap.adapters.gdb = {
        type = "executable",
        command = "gdb",
        args = { "-i", "dap" },
      }

      -- 2. 调试配置：核心是让 GDB 自动解析路径，不再手动写 sourceMap
      dap.configurations.c = {
        {
          name = "Attach to QEMU (Auto Path)",
          type = "gdb",
          request = "attach",
          target = "127.0.0.1:1234",
          cwd = "${workspaceFolder}", -- 必须是项目根目录（~/code/myos-arm64）
          program = "${workspaceFolder}/build/kernel.elf",

          -- 👇 关键：让 GDB 自动解析源码路径，和你手动用 GDB 时完全一样
          initCommands = [[
        target remote 127.0.0.1:1234  -- 连接 QEMU
        file ${workspaceFolder}/build/kernel.elf  -- 加载符号
        directory ${workspaceFolder}  -- 告诉 GDB：源码根目录就是项目根，自动拼接相对路径
      ]],

          -- ✅ 不需要再写任何 sourceMap！GDB 会自动找 boot/boot.S、main.c 等所有文件
          remote = true,
        },
      }

      -- 汇编复用 C 的配置，调试逻辑完全一样
      dap.configurations.asm = dap.configurations.c
    end,
  },
}
