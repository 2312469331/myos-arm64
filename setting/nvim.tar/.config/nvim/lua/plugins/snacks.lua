-- ~/.config/nvim/lua/plugins/snacks.lua
return {
  "folke/snacks.nvim",
  opts = {
    -- 1. 禁用 Snacks 的 notify 模块，解决 noice 冲突
    notify = { enabled = false },
    -- 2. 完全关闭 Profiler，避免误触弹出性能分析界面
    profiler = { enabled = false },
  },
}
