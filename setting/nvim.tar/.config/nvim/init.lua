-- bootstrap lazy.nvim, LazyVim and your plugins
require("config.lazy")
-- 自动换行设置
vim.opt.wrap = true          -- 开启自动换行
vim.opt.linebreak = true     -- 单词边界换行（不截断单词）
vim.opt.showbreak = "↪ "    -- 折行标记（可选，更直观）
vim.opt.scrolloff = 5       -- 滚动时光标始终保持距离上下边界 5 行，避免折行后看不到内容

